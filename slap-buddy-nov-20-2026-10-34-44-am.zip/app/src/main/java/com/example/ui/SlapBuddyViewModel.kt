package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SlapAudioEngine
import com.example.data.AppDatabase
import com.example.data.FriendEntity
import com.example.data.MediaStorageHelper
import com.example.data.MemeAudioEntity
import com.example.data.SlapBuddyRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

class SlapBuddyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SlapBuddyRepository
    private val audioEngine: SlapAudioEngine

    init {
        val dao = AppDatabase.getInstance(application).slapBuddyDao()
        val mediaHelper = MediaStorageHelper(application)
        repository = SlapBuddyRepository(dao, mediaHelper)
        audioEngine = SlapAudioEngine(application, viewModelScope)
    }

    private val selectedFriendId = MutableStateFlow<Long?>(null)
    private val activeSlapMarks = MutableStateFlow<List<SlapMark>>(emptyList())
    private val lastSquishEvent = MutableStateFlow<SquishEvent?>(null)
    private val screenShakeSeq = MutableStateFlow(0L)
    private val isSavingFriend = MutableStateFlow(false)
    private val isImportingAudio = MutableStateFlow(false)
    private val statusMessage = MutableStateFlow<String?>(null)

    private var eventCounter = 0L

    private data class VisualEffectsState(
        val marks: List<SlapMark>,
        val squish: SquishEvent?,
        val shakeSeq: Long,
        val isTalking: Boolean,
        val talkingAmp: Float,
        val playingClipId: Long?
    )

    private data class BusyStatusState(
        val savingFriend: Boolean,
        val importingAudio: Boolean,
        val message: String?
    )

    private val visualEffectsFlow = combine(
        activeSlapMarks,
        lastSquishEvent,
        screenShakeSeq,
        audioEngine.isTalking,
        audioEngine.talkingAmplitude,
        audioEngine.playingClipId
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        VisualEffectsState(
            marks = values[0] as List<SlapMark>,
            squish = values[1] as SquishEvent?,
            shakeSeq = values[2] as Long,
            isTalking = values[3] as Boolean,
            talkingAmp = values[4] as Float,
            playingClipId = values[5] as Long?
        )
    }

    private val busyFlow = combine(
        isSavingFriend,
        isImportingAudio,
        statusMessage
    ) { saving, importing, msg ->
        BusyStatusState(saving, importing, msg)
    }

    val uiState: StateFlow<SlapBuddyUiState> = combine(
        repository.friendsFlow,
        repository.memeAudiosFlow,
        selectedFriendId,
        visualEffectsFlow,
        busyFlow
    ) { friends, audios, selectedId, effects, busy ->
        val activeFriend = friends.firstOrNull { it.id == selectedId } ?: friends.firstOrNull()
        SlapBuddyUiState(
            friends = friends,
            selectedFriend = activeFriend,
            memeAudios = audios,
            activeSlapMarks = effects.marks,
            lastSquishEvent = effects.squish,
            screenShakeSeq = effects.shakeSeq,
            isTalking = effects.isTalking,
            talkingAmplitude = effects.talkingAmp,
            playingClipId = effects.playingClipId,
            isSavingFriend = busy.savingFriend,
            isImportingAudio = busy.importingAudio,
            statusMessage = busy.message
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = SlapBuddyUiState()
    )

    fun selectFriend(friendId: Long) {
        if (selectedFriendId.value != friendId) {
            selectedFriendId.value = friendId
            activeSlapMarks.value = emptyList()
            audioEngine.stopMemePlayback()
        }
    }

    fun onSlap(normX: Float, normY: Float) {
        val currentFriend = uiState.value.selectedFriend ?: return
        val zone = when {
            normY >= 0.56f -> HitZone.STOMACH
            normX < 0.5f -> HitZone.LEFT_CHEEK
            else -> HitZone.RIGHT_CHEEK
        }

        val id = ++eventCounter
        val handRotation = when (zone) {
            HitZone.LEFT_CHEEK -> Random.nextFloat() * 18f + 16f
            HitZone.RIGHT_CHEEK -> -(Random.nextFloat() * 18f + 16f)
            HitZone.STOMACH -> Random.nextFloat() * 16f - 8f
        }
        val word = SLAP_WORDS.random()
        val mark = SlapMark(
            id = id,
            normX = normX.coerceIn(0.08f, 0.92f),
            normY = normY.coerceIn(0.10f, 0.90f),
            zone = zone,
            rotationDeg = handRotation,
            word = word,
            createdAtMs = System.currentTimeMillis()
        )

        activeSlapMarks.update { current -> (current + mark).takeLast(6) }
        lastSquishEvent.value = SquishEvent(id = id, zone = zone)
        screenShakeSeq.update { it + 1L }

        viewModelScope.launch {
            repository.incrementSlap(currentFriend.id)
        }

        audioEngine.playSlapAndRandomMeme(uiState.value.memeAudios)

        viewModelScope.launch {
            delay(1500L)
            activeSlapMarks.update { list -> list.filterNot { it.id == id } }
        }
    }

    suspend fun loadPreviewBitmap(uri: Uri): Bitmap? = repository.loadPreviewBitmap(uri)

    fun addFriend(
        name: String,
        bitmap: Bitmap,
        zoom: Float,
        normOffsetX: Float,
        normOffsetY: Float,
        onComplete: () -> Unit
    ) {
        if (isSavingFriend.value) return
        viewModelScope.launch {
            isSavingFriend.value = true
            try {
                val newId = repository.addFriend(name, bitmap, zoom, normOffsetX, normOffsetY)
                if (newId != null) {
                    selectedFriendId.value = newId
                    onComplete()
                } else {
                    statusMessage.value = "Max 10 friends reached. Long-press one to remove."
                }
            } finally {
                isSavingFriend.value = false
            }
        }
    }

    fun deleteFriend(friend: FriendEntity) {
        viewModelScope.launch {
            repository.deleteFriend(friend)
            if (selectedFriendId.value == friend.id) {
                selectedFriendId.value = null
            }
        }
    }

    fun resetSlapCount(friendId: Long) {
        viewModelScope.launch {
            repository.resetSlapCount(friendId)
        }
    }

    fun importAudioClips(uris: List<Uri>) {
        if (uris.isEmpty() || isImportingAudio.value) return
        viewModelScope.launch {
            isImportingAudio.value = true
            try {
                val count = repository.importMemeAudios(uris)
                if (count == 0) {
                    statusMessage.value = "Could not import selected audio clip(s)."
                }
            } finally {
                isImportingAudio.value = false
            }
        }
    }

    fun previewAudio(audio: MemeAudioEntity) {
        audioEngine.previewAudio(audio)
    }

    fun stopAudio() {
        audioEngine.stopMemePlayback()
    }

    fun deleteAudio(audio: MemeAudioEntity) {
        if (audioEngine.playingClipId.value == audio.id) {
            audioEngine.stopMemePlayback()
        }
        viewModelScope.launch {
            repository.deleteMemeAudio(audio)
        }
    }

    fun clearStatusMessage() {
        statusMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
    }

    companion object {
        private val SLAP_WORDS = listOf(
            "SMACK!",
            "THAPAD!",
            "WHACK!",
            "CHATAK!",
            "POW!",
            "BONK!",
            "SLAP!"
        )
    }
}
