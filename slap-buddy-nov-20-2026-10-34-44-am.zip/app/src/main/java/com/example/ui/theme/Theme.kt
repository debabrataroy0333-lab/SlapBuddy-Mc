package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = ComicRed,
    onPrimary = Color.White,
    primaryContainer = ComicYellow,
    onPrimaryContainer = ComicInk,
    secondary = ComicSkyBlue,
    onSecondary = Color.White,
    secondaryContainer = ComicSkyLight,
    onSecondaryContainer = ComicSkyDeep,
    tertiary = ComicMint,
    onTertiary = ComicInk,
    background = ComicSkyLight,
    onBackground = ComicInk,
    surface = ComicCream,
    onSurface = ComicInk,
    surfaceVariant = ComicYellowSoft,
    onSurfaceVariant = ComicSlate,
    outline = ComicInk,
    outlineVariant = ComicDivider,
    error = ComicRedDark,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = ComicRed,
    onPrimary = Color.White,
    primaryContainer = ComicYellow,
    onPrimaryContainer = ComicInk,
    secondary = ComicSkyBlue,
    onSecondary = ComicInk,
    secondaryContainer = ComicSkyDeep,
    onSecondaryContainer = ComicSkyLight,
    tertiary = ComicMint,
    onTertiary = ComicInk,
    background = Color(0xFF141824),
    onBackground = ComicCream,
    surface = ComicCardDark,
    onSurface = ComicCream,
    surfaceVariant = Color(0xFF2E2B3A),
    onSurfaceVariant = Color(0xFFD0CADF),
    outline = ComicYellow,
    outlineVariant = Color(0xFF3E3B4E),
    error = ComicRed,
    onError = Color.White
)

val SlapBuddyShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun SlapBuddyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = SlapBuddyShapes,
        content = content
    )
}
