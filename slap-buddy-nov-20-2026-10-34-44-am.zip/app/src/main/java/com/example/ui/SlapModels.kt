package com.example.ui

import com.example.data.FriendEntity
import com.example.data.MemeAudioEntity

enum class HitZone {
    LEFT_CHEEK,
    RIGHT_CHEEK,
    STOMACH
}

data class SlapMark(
    val id: Long,
    val normX: Float,
    val normY: Float,
    val zone: HitZone,
    val rotationDeg: Float,
    val word: String,
    val createdAtMs: Long
)

data class SquishEvent(
    val id: Long,
    val zone: HitZone
)

data class SlapBuddyUiState(
    val friends: List<FriendEntity> = emptyList(),
    val selectedFriend: FriendEntity? = null,
    val memeAudios: List<MemeAudioEntity> = emptyList(),
    val activeSlapMarks: List<SlapMark> = emptyList(),
    val lastSquishEvent: SquishEvent? = null,
    val screenShakeSeq: Long = 0L,
    val isTalking: Boolean = false,
    val talkingAmplitude: Float = 0f,
    val playingClipId: Long? = null,
    val isSavingFriend: Boolean = false,
    val isImportingAudio: Boolean = false,
    val statusMessage: String? = null
)
