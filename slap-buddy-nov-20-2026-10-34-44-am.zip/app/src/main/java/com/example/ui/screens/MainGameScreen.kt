package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.FriendEntity
import com.example.data.SlapBuddyRepository
import com.example.ui.HitZone
import com.example.ui.SlapBuddyViewModel
import com.example.ui.components.AddFriendSheet
import com.example.ui.components.CartoonHandprintEffect
import com.example.ui.components.ComicStageBackground
import com.example.ui.components.FriendDockBar
import com.example.ui.components.ManageAudiosSheet
import com.example.ui.components.TalkingSoundWaveOverlay
import com.example.ui.theme.BangersFontFamily
import com.example.ui.theme.ComicInk
import com.example.ui.theme.ComicMint
import com.example.ui.theme.ComicRed
import com.example.ui.theme.ComicSkyBlue
import com.example.ui.theme.ComicYellow
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun MainGameScreen(viewModel: SlapBuddyViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    var showAddFriendSheet by remember { mutableStateOf(false) }
    var showManageAudiosSheet by remember { mutableStateOf(false) }
    var friendToDelete by remember { mutableStateOf<FriendEntity?>(null) }

    LaunchedEffect(uiState.statusMessage) {
        val msg = uiState.statusMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.clearStatusMessage()
    }

    // Screen shake animatables
    val shakeOffsetX = remember { Animatable(0f) }
    val shakeOffsetY = remember { Animatable(0f) }

    LaunchedEffect(uiState.screenShakeSeq) {
        if (uiState.screenShakeSeq == 0L) return@LaunchedEffect
        val amplitudes = listOf(22f, -18f, 14f, -10f, 6f, -3f, 0f)
        for (amp in amplitudes) {
            val dirY = (Random.nextFloat() * 2f - 1f) * amp * 0.6f
            launch { shakeOffsetX.animateTo(amp, tween(28)) }
            shakeOffsetY.animateTo(dirY, tween(28))
        }
        shakeOffsetX.snapTo(0f)
        shakeOffsetY.snapTo(0f)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color.Transparent,
        modifier = Modifier.fillMaxSize()
    ) { _ ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationX = shakeOffsetX.value
                    translationY = shakeOffsetY.value
                }
        ) {
            ComicStageBackground()

            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top HUD
                TopGameHud(
                    selectedFriend = uiState.selectedFriend,
                    audioCount = uiState.memeAudios.size,
                    onResetSlaps = {
                        uiState.selectedFriend?.let { viewModel.resetSlapCount(it.id) }
                    },
                    onOpenAudios = { showManageAudiosSheet = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                )

                // Center Interactive Stage (non-scrolling)
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    val activeFriend = uiState.selectedFriend
                    if (activeFriend == null) {
                        EmptyStageCard(
                            onAddFirstFriend = { showAddFriendSheet = true }
                        )
                    } else {
                        SlapCharacterStage(
                            friend = activeFriend,
                            slapMarks = uiState.activeSlapMarks,
                            lastSquishEvent = uiState.lastSquishEvent,
                            isTalking = uiState.isTalking,
                            talkingAmplitude = uiState.talkingAmplitude,
                            onSlap = { nx, ny -> viewModel.onSlap(nx, ny) }
                        )
                    }
                }

                // Bottom Horizontal Friend Switcher Dock
                FriendDockBar(
                    friends = uiState.friends,
                    selectedFriendId = uiState.selectedFriend?.id,
                    onSelectFriend = { viewModel.selectFriend(it.id) },
                    onRequestDeleteFriend = { friendToDelete = it },
                    onAddFriendClick = {
                        showAddFriendSheet = true
                    }
                )
            }
        }
    }

    if (showAddFriendSheet) {
        if (uiState.friends.size >= SlapBuddyRepository.MAX_FRIENDS) {
            AlertDialog(
                onDismissRequest = { showAddFriendSheet = false },
                title = { Text(stringResource(R.string.add_friend)) },
                text = { Text(stringResource(R.string.max_friends_reached)) },
                confirmButton = {
                    TextButton(onClick = { showAddFriendSheet = false }) {
                        Text("OK")
                    }
                }
            )
        } else {
            AddFriendSheet(
                isSaving = uiState.isSavingFriend,
                onLoadPreview = { uri -> viewModel.loadPreviewBitmap(uri) },
                onSaveFriend = { name, bitmap, zoom, ox, oy ->
                    viewModel.addFriend(name, bitmap, zoom, ox, oy) {
                        showAddFriendSheet = false
                    }
                },
                onDismiss = { showAddFriendSheet = false }
            )
        }
    }

    if (showManageAudiosSheet) {
        ManageAudiosSheet(
            audios = uiState.memeAudios,
            playingClipId = uiState.playingClipId,
            isImporting = uiState.isImportingAudio,
            onImportAudios = { uris -> viewModel.importAudioClips(uris) },
            onTestAudio = { clip -> viewModel.previewAudio(clip) },
            onDeleteAudio = { clip -> viewModel.deleteAudio(clip) },
            onDismiss = {
                viewModel.stopAudio()
                showManageAudiosSheet = false
            }
        )
    }

    val pendingDelete = friendToDelete
    if (pendingDelete != null) {
        AlertDialog(
            onDismissRequest = { friendToDelete = null },
            title = { Text(stringResource(R.string.delete_friend_title, pendingDelete.name)) },
            text = {
                Text(
                    stringResource(
                        R.string.delete_friend_message,
                        pendingDelete.name,
                        pendingDelete.slapCount
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteFriend(pendingDelete)
                        friendToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ComicRed,
                        contentColor = Color.White
                    )
                ) {
                    Text(stringResource(R.string.delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { friendToDelete = null }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
private fun TopGameHud(
    selectedFriend: FriendEntity?,
    audioCount: Int,
    onResetSlaps: () -> Unit,
    onOpenAudios: () -> Unit,
    modifier: Modifier = Modifier
) {
    val slapCount = selectedFriend?.slapCount ?: 0
    val counterPop = remember { Animatable(1f) }
    LaunchedEffect(slapCount) {
        if (slapCount > 0) {
            counterPop.snapTo(1.24f)
            counterPop.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            )
        }
    }

    Row(
        modifier = modifier.widthIn(max = 620.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Slap Counter Comic Pill
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = ComicYellow,
            shadowElevation = 6.dp,
            modifier = Modifier
                .graphicsLayer {
                    scaleX = counterPop.value
                    scaleY = counterPop.value
                }
                .border(2.5.dp, ComicInk, RoundedCornerShape(20.dp))
                .testTag("slap_counter_badge")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(
                    start = 12.dp,
                    end = if (slapCount > 0) 4.dp else 12.dp,
                    top = 6.dp,
                    bottom = 6.dp
                )
            ) {
                Text(
                    text = stringResource(R.string.slap_counter_label, slapCount),
                    fontFamily = BangersFontFamily,
                    fontSize = 22.sp,
                    color = ComicInk,
                    letterSpacing = 1.sp,
                    maxLines = 1
                )
                if (slapCount > 0) {
                    IconButton(
                        onClick = onResetSlaps,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("reset_slaps_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = stringResource(R.string.reset_slaps),
                            tint = ComicInk,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Meme Audios Manager Button
        Surface(
            onClick = onOpenAudios,
            shape = RoundedCornerShape(20.dp),
            color = ComicSkyBlue,
            shadowElevation = 6.dp,
            modifier = Modifier
                .border(2.5.dp, ComicInk, RoundedCornerShape(20.dp))
                .testTag("manage_audios_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.LibraryMusic,
                    contentDescription = null,
                    tint = ComicInk,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = stringResource(R.string.meme_audios),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = ComicInk
                )
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (audioCount > 0) ComicRed else ComicInk)
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = audioCount.toString(),
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyStageCard(onAddFirstFriend: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 10.dp,
        modifier = Modifier
            .widthIn(max = 380.dp)
            .fillMaxWidth()
            .border(3.dp, ComicInk, RoundedCornerShape(28.dp))
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_buddy),
                contentDescription = stringResource(R.string.empty_stage_title),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(168.dp)
                    .clip(CircleShape)
                    .border(3.dp, ComicInk, CircleShape)
            )
            Text(
                text = stringResource(R.string.empty_stage_title),
                style = MaterialTheme.typography.displayMedium,
                color = ComicRed,
                textAlign = TextAlign.Center
            )
            Text(
                text = stringResource(R.string.empty_stage_subtitle),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = onAddFirstFriend,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ComicYellow,
                    contentColor = ComicInk
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .border(2.5.dp, ComicInk, RoundedCornerShape(18.dp))
                    .testTag("empty_add_friend_button")
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.add_first_friend),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

@Composable
private fun SlapCharacterStage(
    friend: FriendEntity,
    slapMarks: List<com.example.ui.SlapMark>,
    lastSquishEvent: com.example.ui.SquishEvent?,
    isTalking: Boolean,
    talkingAmplitude: Float,
    onSlap: (normX: Float, normY: Float) -> Unit
) {
    val haptic = LocalHapticFeedback.current

    // Squish / Stretch / Wobble animatables
    val squishScaleX = remember { Animatable(1f) }
    val squishScaleY = remember { Animatable(1f) }
    val squishRotZ = remember { Animatable(0f) }
    val squishRotY = remember { Animatable(0f) }
    val squishShiftX = remember { Animatable(0f) }
    val squishShiftY = remember { Animatable(0f) }

    LaunchedEffect(lastSquishEvent?.id) {
        val ev = lastSquishEvent ?: return@LaunchedEffect
        when (ev.zone) {
            HitZone.LEFT_CHEEK -> {
                squishScaleX.snapTo(0.83f)
                squishScaleY.snapTo(1.13f)
                squishRotZ.snapTo(13f)
                squishRotY.snapTo(20f)
                squishShiftX.snapTo(26f)
                squishShiftY.snapTo(-6f)
            }
            HitZone.RIGHT_CHEEK -> {
                squishScaleX.snapTo(0.83f)
                squishScaleY.snapTo(1.13f)
                squishRotZ.snapTo(-13f)
                squishRotY.snapTo(-20f)
                squishShiftX.snapTo(-26f)
                squishShiftY.snapTo(-6f)
            }
            HitZone.STOMACH -> {
                squishScaleX.snapTo(1.18f)
                squishScaleY.snapTo(0.78f)
                squishRotZ.snapTo((Random.nextFloat() - 0.5f) * 8f)
                squishRotY.snapTo(0f)
                squishShiftX.snapTo(0f)
                squishShiftY.snapTo(-24f)
            }
        }
        val wobbleSpring = spring<Float>(
            dampingRatio = 0.28f,
            stiffness = 520f
        )
        launch { squishScaleX.animateTo(1f, wobbleSpring) }
        launch { squishScaleY.animateTo(1f, wobbleSpring) }
        launch { squishRotZ.animateTo(0f, wobbleSpring) }
        launch { squishRotY.animateTo(0f, wobbleSpring) }
        launch { squishShiftX.animateTo(0f, wobbleSpring) }
        launch { squishShiftY.animateTo(0f, wobbleSpring) }
    }

    // Talking animation synced with audio amplitude
    val smoothAmp by animateFloatAsState(
        targetValue = if (isTalking) talkingAmplitude else 0f,
        animationSpec = tween(durationMillis = 36),
        label = "talkAmp"
    )
    val talkPhase = remember(isTalking) { Animatable(0f) }
    LaunchedEffect(isTalking) {
        if (!isTalking) {
            talkPhase.snapTo(0f)
            return@LaunchedEffect
        }
        while (true) {
            talkPhase.animateTo(
                targetValue = talkPhase.value + (Math.PI * 2.0).toFloat(),
                animationSpec = tween(durationMillis = 260)
            )
        }
    }

    val talkScaleX = 1f + smoothAmp * 0.09f
    val talkScaleY = 1f + smoothAmp * 0.14f
    val talkBounceY = -smoothAmp * 18f
    val talkTilt = if (isTalking) sin(talkPhase.value) * (smoothAmp * 4.5f) else 0f

    BoxWithConstraints(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        val stageSide = min(maxWidth, maxHeight - 76.dp).coerceIn(220.dp, 440.dp)
        var photoBoxSize by remember { mutableStateOf(IntSize(1, 1)) }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(stageSide)
                    .graphicsLayer {
                        scaleX = squishScaleX.value * talkScaleX
                        scaleY = squishScaleY.value * talkScaleY
                        rotationZ = squishRotZ.value + talkTilt
                        rotationY = squishRotY.value
                        translationX = squishShiftX.value
                        translationY = squishShiftY.value + talkBounceY
                        cameraDistance = 14f * density
                    }
            ) {
                // Comic Card Shadow
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .offset(x = 6.dp, y = 8.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(ComicInk)
                )

                // Friend Photo + Invisible Hitboxes (Left Cheek, Right Cheek, Stomach)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(32.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(4.dp, ComicInk, RoundedCornerShape(32.dp))
                        .onSizeChanged { photoBoxSize = it }
                        .pointerInput(friend.id) {
                            detectTapGestures { tapOffset ->
                                val w = photoBoxSize.width.coerceAtLeast(1).toFloat()
                                val h = photoBoxSize.height.coerceAtLeast(1).toFloat()
                                val normX = (tapOffset.x / w).coerceIn(0f, 1f)
                                val normY = (tapOffset.y / h).coerceIn(0f, 1f)
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onSlap(normX, normY)
                            }
                        }
                        .testTag("slap_character_stage")
                ) {
                    AsyncImage(
                        model = File(friend.imagePath),
                        contentDescription = "Slap ${friend.name}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    if (isTalking) {
                        TalkingSoundWaveOverlay(amplitude = smoothAmp)
                    }

                    // Active Handprint Marks + Comic Pop-up Words
                    for (mark in slapMarks) {
                        androidx.compose.runtime.key(mark.id) {
                            CartoonHandprintEffect(
                                mark = mark,
                                containerWidthPx = photoBoxSize.width.toFloat(),
                                containerHeightPx = photoBoxSize.height.toFloat()
                            )
                        }
                    }
                }

                // Talking pill badge
                androidx.compose.animation.AnimatedVisibility(
                    visible = isTalking,
                    enter = scaleIn() + fadeIn(),
                    exit = scaleOut() + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = ComicMint,
                        modifier = Modifier.border(2.dp, ComicInk, RoundedCornerShape(14.dp))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = ComicInk,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = stringResource(R.string.talking_badge),
                                fontFamily = BangersFontFamily,
                                fontSize = 16.sp,
                                color = ComicInk,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Friend Name & Hit Zone Tip
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                shadowElevation = 4.dp,
                modifier = Modifier.border(2.dp, ComicInk, RoundedCornerShape(18.dp))
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = friend.name.uppercase(),
                        fontFamily = BangersFontFamily,
                        fontSize = 24.sp,
                        color = ComicRed,
                        letterSpacing = 1.3.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = stringResource(R.string.tap_zones_hint),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
