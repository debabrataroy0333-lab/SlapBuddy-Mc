package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.HitZone
import com.example.ui.SlapMark
import com.example.ui.theme.BangersFontFamily
import com.example.ui.theme.ComicInk
import com.example.ui.theme.ComicOrange
import com.example.ui.theme.ComicRed
import com.example.ui.theme.ComicSkyBlue
import com.example.ui.theme.ComicYellow
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun ComicStageBackground(modifier: Modifier = Modifier) {
    val isDark = isSystemInDarkTheme()
    val centerColor = if (isDark) Color(0xFF1F2A44) else Color(0xFFFFF8C9)
    val outerColor = if (isDark) Color(0xFF111521) else Color(0xFF6AD4FF)
    val rayColor = if (isDark) Color(0x18FFE600) else Color(0x28FFFFFF)
    val dotColor = if (isDark) Color(0x1628B8FF) else Color(0x1C0A3A5C)

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(centerColor, outerColor),
                center = Offset(size.width * 0.5f, size.height * 0.45f),
                radius = size.maxDimension * 0.8f
            )
        )

        // Comic sunburst rays
        val origin = Offset(size.width * 0.5f, size.height * 0.45f)
        val rayRadius = size.maxDimension * 1.1f
        val rayCount = 16
        for (i in 0 until rayCount) {
            val startAngle = (i * (360f / rayCount)) * (PI / 180.0)
            val endAngle = ((i + 0.42f) * (360f / rayCount)) * (PI / 180.0)
            val path = Path().apply {
                moveTo(origin.x, origin.y)
                lineTo(
                    origin.x + (cos(startAngle) * rayRadius).toFloat(),
                    origin.y + (sin(startAngle) * rayRadius).toFloat()
                )
                lineTo(
                    origin.x + (cos(endAngle) * rayRadius).toFloat(),
                    origin.y + (sin(endAngle) * rayRadius).toFloat()
                )
                close()
            }
            drawPath(path = path, color = rayColor)
        }

        // Subtle halftone dot matrix along top and bottom borders
        val spacing = 22.dp.toPx()
        var y = spacing * 0.6f
        var row = 0
        while (y < size.height) {
            val edgeFactor = kotlin.math.abs((y / size.height) - 0.45f) * 2f
            if (edgeFactor > 0.35f) {
                var x = if (row % 2 == 0) spacing * 0.5f else spacing
                while (x < size.width) {
                    drawCircle(
                        color = dotColor,
                        radius = (1.6f + edgeFactor * 1.4f).dp.toPx(),
                        center = Offset(x, y)
                    )
                    x += spacing
                }
            }
            y += spacing
            row++
        }
    }
}

@Composable
fun CartoonHandprintEffect(
    mark: SlapMark,
    containerWidthPx: Float,
    containerHeightPx: Float
) {
    val popScale = remember(mark.id) { Animatable(0.42f) }
    val alphaAnim = remember(mark.id) { Animatable(1f) }
    val floatOffsetY = remember(mark.id) { Animatable(0f) }

    LaunchedEffect(mark.id) {
        popScale.animateTo(
            targetValue = 1.0f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessHigh
            )
        )
    }

    LaunchedEffect(mark.id) {
        floatOffsetY.animateTo(
            targetValue = -46f,
            animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing)
        )
    }

    LaunchedEffect(mark.id) {
        // Stay punchy for 450ms, then fade out completely by 1500ms
        kotlinx.coroutines.delay(450L)
        alphaAnim.animateTo(
            targetValue = 0f,
            animationSpec = tween(durationMillis = 1050, easing = FastOutSlowInEasing)
        )
    }

    val handSizeDp = 96.dp
    val centerX = mark.normX * containerWidthPx
    val centerY = mark.normY * containerHeightPx
    val flipHand = mark.zone == HitZone.RIGHT_CHEEK

    // 1. Cartoon Red Handprint right on the touched coordinate
    Canvas(
        modifier = Modifier
            .offset {
                val halfPx = handSizeDp.toPx() / 2f
                IntOffset(
                    x = (centerX - halfPx).roundToInt(),
                    y = (centerY - halfPx).roundToInt()
                )
            }
            .size(handSizeDp)
            .graphicsLayer {
                scaleX = popScale.value * if (flipHand) -1f else 1f
                scaleY = popScale.value
                rotationZ = mark.rotationDeg
                alpha = alphaAnim.value
            }
    ) {
        drawCartoonHandprint()
    }

    // 2. Comic Starburst Word Pop-up ("SMACK!", "THAPAD!", etc.)
    val bubbleWidthDp = 150.dp
    val bubbleHeightDp = 78.dp
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .offset {
                val halfW = bubbleWidthDp.toPx() / 2f
                val halfH = bubbleHeightDp.toPx() / 2f
                val clampedX = centerX.coerceIn(halfW * 0.7f, containerWidthPx - halfW * 0.7f)
                val targetY = (centerY - 58.dp.toPx() + floatOffsetY.value)
                    .coerceIn(halfH * 0.5f, containerHeightPx - halfH * 0.5f)
                IntOffset(
                    x = (clampedX - halfW).roundToInt(),
                    y = (targetY - halfH).roundToInt()
                )
            }
            .size(width = bubbleWidthDp, height = bubbleHeightDp)
            .graphicsLayer {
                val s = 0.75f + popScale.value * 0.32f
                scaleX = s
                scaleY = s
                rotationZ = (mark.rotationDeg * 0.35f).coerceIn(-14f, 14f)
                alpha = alphaAnim.value
            }
    ) {
        ComicStarburstBubble(word = mark.word)
    }
}

private fun DrawScope.drawCartoonHandprint() {
    val w = size.width
    val h = size.height
    val handRed = Color(0xFFE6192E)
    val handHighlight = Color(0xFFFF5964)
    val strokeColor = ComicInk
    val strokeWidth = w * 0.036f

    // Impact splatter drops
    val drops = listOf(
        Offset(w * 0.12f, h * 0.22f) to w * 0.032f,
        Offset(w * 0.88f, h * 0.20f) to w * 0.036f,
        Offset(w * 0.90f, h * 0.76f) to w * 0.028f,
        Offset(w * 0.14f, h * 0.78f) to w * 0.026f
    )
    for ((pos, rad) in drops) {
        drawCircle(color = handRed, radius = rad, center = pos)
        drawCircle(
            color = strokeColor,
            radius = rad,
            center = pos,
            style = Stroke(width = strokeWidth * 0.7f)
        )
    }

    // Palm
    val palmCenter = Offset(w * 0.52f, h * 0.62f)
    drawOval(
        color = handRed,
        topLeft = Offset(palmCenter.x - w * 0.22f, palmCenter.y - h * 0.19f),
        size = Size(w * 0.44f, h * 0.38f)
    )
    drawOval(
        color = strokeColor,
        topLeft = Offset(palmCenter.x - w * 0.22f, palmCenter.y - h * 0.19f),
        size = Size(w * 0.44f, h * 0.38f),
        style = Stroke(width = strokeWidth)
    )

    // 4 Fingers + Thumb
    data class FingerSpec(
        val cx: Float,
        val cy: Float,
        val fw: Float,
        val fh: Float,
        val angle: Float
    )

    val fingers = listOf(
        // Thumb (left)
        FingerSpec(w * 0.22f, h * 0.54f, w * 0.13f, h * 0.28f, -40f),
        // Index
        FingerSpec(w * 0.34f, h * 0.28f, w * 0.12f, h * 0.34f, -15f),
        // Middle
        FingerSpec(w * 0.50f, h * 0.22f, w * 0.125f, h * 0.38f, -2f),
        // Ring
        FingerSpec(w * 0.66f, h * 0.27f, w * 0.12f, h * 0.34f, 12f),
        // Pinky
        FingerSpec(w * 0.80f, h * 0.38f, w * 0.105f, h * 0.27f, 26f)
    )

    for (f in fingers) {
        rotate(degrees = f.angle, pivot = Offset(f.cx, f.cy)) {
            val topLeft = Offset(f.cx - f.fw / 2f, f.cy - f.fh / 2f)
            val rectSize = Size(f.fw, f.fh)
            drawOval(color = handRed, topLeft = topLeft, size = rectSize)
            drawOval(
                color = strokeColor,
                topLeft = topLeft,
                size = rectSize,
                style = Stroke(width = strokeWidth)
            )
        }
    }

    // Re-fill inner palm center to seamlessly merge finger bases
    drawOval(
        color = handRed,
        topLeft = Offset(palmCenter.x - w * 0.20f, palmCenter.y - h * 0.17f),
        size = Size(w * 0.40f, h * 0.34f)
    )
    // Glossy comic highlight
    drawOval(
        color = handHighlight,
        topLeft = Offset(palmCenter.x - w * 0.11f, palmCenter.y - h * 0.08f),
        size = Size(w * 0.14f, h * 0.10f)
    )
}

@Composable
private fun ComicStarburstBubble(word: String) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val spikes = 12
            val outerRx = size.width * 0.49f
            val outerRy = size.height * 0.48f
            val innerRx = size.width * 0.33f
            val innerRy = size.height * 0.30f

            val path = Path()
            for (i in 0 until spikes * 2) {
                val angle = (i * PI / spikes) - PI / 2.0
                val rx = if (i % 2 == 0) outerRx else innerRx
                val ry = if (i % 2 == 0) outerRy else innerRy
                val px = cx + (cos(angle) * rx).toFloat()
                val py = cy + (sin(angle) * ry).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()

            // Drop shadow
            drawPath(
                path = Path().apply {
                    addPath(path, Offset(3.dp.toPx(), 3.dp.toPx()))
                },
                color = ComicInk
            )
            // Bright yellow starburst fill
            drawPath(path = path, color = ComicYellow)
            // Bold ink border
            drawPath(
                path = path,
                color = ComicInk,
                style = Stroke(
                    width = 2.8.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }

        // Ink shadow text + crisp crimson comic text
        Text(
            text = word,
            fontFamily = BangersFontFamily,
            fontSize = 27.sp,
            fontWeight = FontWeight.Normal,
            color = ComicInk,
            letterSpacing = 1.5.sp,
            modifier = Modifier.offset(x = 2.dp, y = 2.dp)
        )
        Text(
            text = word,
            fontFamily = BangersFontFamily,
            fontSize = 27.sp,
            fontWeight = FontWeight.Normal,
            color = ComicRed,
            letterSpacing = 1.5.sp
        )
    }
}

@Composable
fun TalkingSoundWaveOverlay(
    amplitude: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val pulse = amplitude.coerceIn(0f, 1f)
        if (pulse < 0.05f) return@Canvas

        val strokeW = (2.5f + pulse * 3f).dp.toPx()
        val arcSpread = 10.dp.toPx() * pulse

        // Left comic sound arcs
        drawArc(
            color = ComicYellow,
            startAngle = 145f,
            sweepAngle = 70f,
            useCenter = false,
            topLeft = Offset(-arcSpread, size.height * 0.18f),
            size = Size(size.width * 0.16f, size.height * 0.28f),
            style = Stroke(width = strokeW, cap = StrokeCap.Round)
        )
        // Right comic sound arcs
        drawArc(
            color = ComicOrange,
            startAngle = -35f,
            sweepAngle = 70f,
            useCenter = false,
            topLeft = Offset(size.width * 0.84f + arcSpread, size.height * 0.18f),
            size = Size(size.width * 0.16f, size.height * 0.28f),
            style = Stroke(width = strokeW, cap = StrokeCap.Round)
        )
        // Subtle sky-blue outer aura ring
        drawRoundRect(
            color = ComicSkyBlue.copy(alpha = 0.25f + pulse * 0.35f),
            style = Stroke(width = (3f + pulse * 4f).dp.toPx())
        )
    }
}
