package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Playful Comic-Arcade Palette
val ComicRed = Color(0xFFFF2E4C)
val ComicRedDark = Color(0xFFD11132)
val ComicYellow = Color(0xFFFFE600)
val ComicYellowSoft = Color(0xFFFFF49C)
val ComicSkyBlue = Color(0xFF28B8FF)
val ComicSkyLight = Color(0xFFE7F8FF)
val ComicSkyDeep = Color(0xFF0A3A5C)
val ComicMint = Color(0xFF2CE574)
val ComicOrange = Color(0xFFFF7A1A)
val ComicInk = Color(0xFF17151C)
val ComicCream = Color(0xFFFFFDF7)
val ComicCardDark = Color(0xFF22202B)
val ComicSlate = Color(0xFF5D5A6B)
val ComicDivider = Color(0xFFE5DFCE)
