package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "friends")
data class FriendEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val imagePath: String,
    val slapCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
