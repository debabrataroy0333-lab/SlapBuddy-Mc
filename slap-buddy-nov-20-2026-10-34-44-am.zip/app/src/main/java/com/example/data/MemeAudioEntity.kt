package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "meme_audios")
data class MemeAudioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val filePath: String,
    val durationMs: Long = 0L,
    val envelopeCsv: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
