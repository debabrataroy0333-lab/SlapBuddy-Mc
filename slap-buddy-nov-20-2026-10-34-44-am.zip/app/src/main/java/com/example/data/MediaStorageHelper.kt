package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class ImportedAudioData(
    val title: String,
    val filePath: String,
    val durationMs: Long,
    val envelopeCsv: String
)

class MediaStorageHelper(private val context: Context) {

    private val friendsDir: File
        get() = File(context.filesDir, "friends").apply { if (!exists()) mkdirs() }

    private val audiosDir: File
        get() = File(context.filesDir, "audios").apply { if (!exists()) mkdirs() }

    suspend fun loadPreviewBitmap(uri: Uri, maxDim: Int = 1024): Bitmap? =
        withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                        decoder.isMutableRequired = true
                        val w = info.size.width
                        val h = info.size.height
                        val longest = max(w, h)
                        if (longest > maxDim) {
                            val ratio = maxDim.toFloat() / longest.toFloat()
                            decoder.setTargetSize(
                                (w * ratio).toInt().coerceAtLeast(1),
                                (h * ratio).toInt().coerceAtLeast(1)
                            )
                        }
                    }
                } else {
                    val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it, null, boundsOpts)
                    }
                    var sampleSize = 1
                    val longest = max(boundsOpts.outWidth, boundsOpts.outHeight)
                    while (longest / sampleSize > maxDim) {
                        sampleSize *= 2
                    }
                    val decodeOpts = BitmapFactory.Options().apply {
                        inSampleSize = sampleSize
                        inMutable = true
                    }
                    context.contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it, null, decodeOpts)
                    }
                }
            } catch (_: Exception) {
                null
            }
        }

    suspend fun saveCroppedFriendBitmap(
        source: Bitmap,
        zoom: Float,
        normOffsetX: Float,
        normOffsetY: Float,
        outputSize: Int = 800
    ): String = withContext(Dispatchers.IO) {
        val output = Bitmap.createBitmap(outputSize, outputSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val srcW = source.width.toFloat().coerceAtLeast(1f)
        val srcH = source.height.toFloat().coerceAtLeast(1f)
        // Base scale matches ContentScale.Crop inside a 1:1 square
        val baseScale = max(outputSize / srcW, outputSize / srcH)
        val totalScale = baseScale * zoom.coerceIn(1f, 5f)

        val matrix = Matrix().apply {
            postTranslate(-srcW / 2f, -srcH / 2f)
            postScale(totalScale, totalScale)
            postTranslate(
                outputSize / 2f + normOffsetX * outputSize,
                outputSize / 2f + normOffsetY * outputSize
            )
        }

        canvas.drawBitmap(source, matrix, paint)

        val file = File(friendsDir, "friend_${UUID.randomUUID()}.jpg")
        FileOutputStream(file).use { out ->
            output.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        output.recycle()
        file.absolutePath
    }

    suspend fun importMemeAudio(uri: Uri): ImportedAudioData? = withContext(Dispatchers.IO) {
        try {
            val displayName = resolveDisplayName(uri) ?: "Meme Clip"
            val ext = displayName.substringAfterLast('.', "").lowercase()
                .takeIf { it in setOf("mp3", "wav", "m4a", "ogg", "aac") } ?: "mp3"
            val cleanTitle = displayName.substringBeforeLast('.').ifBlank { displayName }

            val destFile = File(audiosDir, "audio_${UUID.randomUUID()}.$ext")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext null

            val durationMs = extractDurationMs(destFile.absolutePath)
            val envelopeCsv = extractEnvelopeCsv(destFile.absolutePath)

            ImportedAudioData(
                title = cleanTitle,
                filePath = destFile.absolutePath,
                durationMs = durationMs,
                envelopeCsv = envelopeCsv
            )
        } catch (_: Exception) {
            null
        }
    }

    fun deleteFileIfExists(path: String) {
        try {
            val file = File(path)
            if (file.exists()) file.delete()
        } catch (_: Exception) {
        }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun extractDurationMs(path: String): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Decodes local audio into a 30ms-step normalized RMS envelope (0..100) for real-time
     * speech-synced bounce animations without needing RECORD_AUDIO permissions.
     */
    private fun extractEnvelopeCsv(path: String): String {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        return try {
            extractor.setDataSource(path)
            var audioTrackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val trackFormat = extractor.getTrackFormat(i)
                val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    format = trackFormat
                    break
                }
            }
            if (audioTrackIndex < 0 || format == null) return ""

            val mime = format.getString(MediaFormat.KEY_MIME) ?: return ""
            extractor.selectTrack(audioTrackIndex)

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else 44100
            var channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else 1

            val samplesPerBucket = ((sampleRate * channelCount) * 0.030).toInt().coerceAtLeast(256)
            var sumSq = 0.0
            var countInBucket = 0
            val rawRms = ArrayList<Double>(256)

            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var iterations = 0
            val maxIterations = 8000 // Safety bound for very long clips (~30s+ audio)

            while (!outputDone && iterations < maxIterations) {
                iterations++
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(5000)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)
                        if (inBuf != null) {
                            val sampleSize = extractor.readSampleData(inBuf, 0)
                            if (sampleSize < 0) {
                                codec.queueInputBuffer(
                                    inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                )
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(
                                    inIdx, 0, sampleSize, extractor.sampleTime, 0
                                )
                                extractor.advance()
                            }
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(bufferInfo, 5000)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val outFormat = codec.outputFormat
                    if (outFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (outFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channelCount = outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                } else if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && bufferInfo.size > 0) {
                        outBuf.position(bufferInfo.offset)
                        outBuf.limit(bufferInfo.offset + bufferInfo.size)
                        val shortBuf = outBuf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        while (shortBuf.hasRemaining() && rawRms.size < 1500) {
                            val s = shortBuf.get().toDouble() / 32768.0
                            sumSq += s * s
                            countInBucket++
                            if (countInBucket >= samplesPerBucket) {
                                rawRms.add(sqrt(sumSq / countInBucket))
                                sumSq = 0.0
                                countInBucket = 0
                            }
                        }
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                }
            }
            if (countInBucket > 0) {
                rawRms.add(sqrt(sumSq / countInBucket))
            }
            if (rawRms.isEmpty()) return ""

            val peak = max(rawRms.maxOrNull() ?: 0.01, 0.01)
            rawRms.joinToString(",") { rms ->
                val norm = ((rms / peak) * 100.0).toInt().coerceIn(0, 100)
                norm.toString()
            }
        } catch (_: Exception) {
            ""
        } finally {
            try {
                codec?.stop()
                codec?.release()
            } catch (_: Exception) {
            }
            try {
                extractor.release()
            } catch (_: Exception) {
            }
        }
    }
}
