package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SlapBuddyDao {
    @Query("SELECT * FROM friends ORDER BY createdAt ASC")
    fun observeFriends(): Flow<List<FriendEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFriend(friend: FriendEntity): Long

    @Query("UPDATE friends SET slapCount = slapCount + 1 WHERE id = :friendId")
    suspend fun incrementSlapCount(friendId: Long)

    @Query("UPDATE friends SET slapCount = 0 WHERE id = :friendId")
    suspend fun resetSlapCount(friendId: Long)

    @Query("DELETE FROM friends WHERE id = :friendId")
    suspend fun deleteFriendById(friendId: Long)

    @Query("SELECT COUNT(*) FROM friends")
    suspend fun getFriendCount(): Int

    @Query("SELECT * FROM meme_audios ORDER BY createdAt DESC")
    fun observeMemeAudios(): Flow<List<MemeAudioEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemeAudio(audio: MemeAudioEntity): Long

    @Query("DELETE FROM meme_audios WHERE id = :audioId")
    suspend fun deleteMemeAudioById(audioId: Long)
}
