package com.example.data

import android.graphics.Bitmap
import android.net.Uri
import kotlinx.coroutines.flow.Flow

class SlapBuddyRepository(
    private val dao: SlapBuddyDao,
    private val mediaHelper: MediaStorageHelper
) {
    val friendsFlow: Flow<List<FriendEntity>> = dao.observeFriends()
    val memeAudiosFlow: Flow<List<MemeAudioEntity>> = dao.observeMemeAudios()

    suspend fun loadPreviewBitmap(uri: Uri): Bitmap? = mediaHelper.loadPreviewBitmap(uri)

    suspend fun addFriend(
        name: String,
        bitmap: Bitmap,
        zoom: Float,
        normOffsetX: Float,
        normOffsetY: Float
    ): Long? {
        if (dao.getFriendCount() >= MAX_FRIENDS) return null
        val path = mediaHelper.saveCroppedFriendBitmap(
            source = bitmap,
            zoom = zoom,
            normOffsetX = normOffsetX,
            normOffsetY = normOffsetY
        )
        return dao.insertFriend(
            FriendEntity(
                name = name.trim(),
                imagePath = path
            )
        )
    }

    suspend fun incrementSlap(friendId: Long) {
        dao.incrementSlapCount(friendId)
    }

    suspend fun resetSlapCount(friendId: Long) {
        dao.resetSlapCount(friendId)
    }

    suspend fun deleteFriend(friend: FriendEntity) {
        dao.deleteFriendById(friend.id)
        mediaHelper.deleteFileIfExists(friend.imagePath)
    }

    suspend fun importMemeAudios(uris: List<Uri>): Int {
        var added = 0
        for (uri in uris) {
            val imported = mediaHelper.importMemeAudio(uri)
            if (imported != null) {
                dao.insertMemeAudio(
                    MemeAudioEntity(
                        title = imported.title,
                        filePath = imported.filePath,
                        durationMs = imported.durationMs,
                        envelopeCsv = imported.envelopeCsv
                    )
                )
                added++
            }
        }
        return added
    }

    suspend fun deleteMemeAudio(audio: MemeAudioEntity) {
        dao.deleteMemeAudioById(audio.id)
        mediaHelper.deleteFileIfExists(audio.filePath)
    }

    companion object {
        const val MAX_FRIENDS = 10
    }
}
