package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.SlapBuddyViewModel
import com.example.ui.screens.MainGameScreen
import com.example.ui.theme.SlapBuddyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SlapBuddyTheme {
                val viewModel: SlapBuddyViewModel = viewModel()
                MainGameScreen(viewModel = viewModel)
            }
        }
    }
}
