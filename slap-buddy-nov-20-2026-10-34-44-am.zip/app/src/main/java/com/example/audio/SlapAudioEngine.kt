package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import com.example.data.MemeAudioEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

class SlapAudioEngine(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(6)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    @Volatile
    private var slapSoundId: Int = 0

    @Volatile
    private var slapLoaded: Boolean = false

    private var mediaPlayer: MediaPlayer? = null
    private var playbackJob: Job? = null
    private var envelopeSyncJob: Job? = null
    private var lastPlayedAudioId: Long? = null

    private val _isTalking = MutableStateFlow(false)
    val isTalking: StateFlow<Boolean> = _isTalking.asStateFlow()

    private val _talkingAmplitude = MutableStateFlow(0f)
    val talkingAmplitude: StateFlow<Float> = _talkingAmplitude.asStateFlow()

    private val _playingClipId = MutableStateFlow<Long?>(null)
    val playingClipId: StateFlow<Long?> = _playingClipId.asStateFlow()

    init {
        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0 && sampleId == slapSoundId) {
                slapLoaded = true
            }
        }
        scope.launch {
            prepareSynthesizedSlapWav()
        }
    }

    private suspend fun prepareSynthesizedSlapWav() = withContext(Dispatchers.IO) {
        try {
            val wavFile = File(context.cacheDir, "synthesized_slap.wav")
            val sampleRate = 44100
            val durationSec = 0.165
            val numSamples = (sampleRate * durationSec).toInt()
            val pcm = ShortArray(numSamples)
            val rng = Random(42)

            var prevFiltered = 0.0
            var phaseMid = 0.0
            var phaseThud = 0.0

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate

                // 1. Sharp crack transient (first 16ms)
                val crackEnv = exp(-t * 210.0)
                val noise = rng.nextDouble(-1.0, 1.0)
                // Gentle one-pole smoothing for punchy slap timbre
                prevFiltered = 0.58 * noise + 0.42 * prevFiltered

                // 2. Whippy skin-clap pitch sweep (920Hz -> 240Hz)
                val midFreq = 240.0 + 680.0 * exp(-t * 48.0)
                phaseMid += 2.0 * PI * midFreq / sampleRate
                val midEnv = exp(-t * 36.0)
                val midTone = sin(phaseMid) * midEnv

                // 3. Low-end comic thud (155Hz -> 60Hz)
                val thudFreq = 60.0 + 95.0 * exp(-t * 28.0)
                phaseThud += 2.0 * PI * thudFreq / sampleRate
                val thudEnv = exp(-t * 20.0)
                val thudTone = sin(phaseThud) * thudEnv

                // Tail slap noise
                val tailNoiseEnv = exp(-t * 34.0)

                val mixed = (prevFiltered * (crackEnv * 0.95 + tailNoiseEnv * 0.55)) +
                    (midTone * 0.45) +
                    (thudTone * 0.52)

                // Soft saturation limiter for crisp loudness without harsh digital clipping
                val saturated = kotlin.math.tanh(mixed * 1.65)
                pcm[i] = (saturated * 32000.0).toInt().coerceIn(-32767, 32767).toShort()
            }

            writePcmWav(wavFile, pcm, sampleRate)
            slapSoundId = soundPool.load(wavFile.absolutePath, 1)
        } catch (_: Exception) {
        }
    }

    private fun writePcmWav(file: File, pcm: ShortArray, sampleRate: Int) {
        val dataSize = pcm.size * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(36 + dataSize)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16) // PCM chunk size
            putShort(1) // AudioFormat = PCM
            putShort(1) // Mono
            putInt(sampleRate)
            putInt(sampleRate * 2) // ByteRate
            putShort(2) // BlockAlign
            putShort(16) // BitsPerSample
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(dataSize)
        }
        FileOutputStream(file).use { out ->
            out.write(header.array())
            val dataBytes = ByteBuffer.allocate(dataSize).order(ByteOrder.LITTLE_ENDIAN)
            for (sample in pcm) {
                dataBytes.putShort(sample)
            }
            out.write(dataBytes.array())
        }
    }

    fun playSlapAndRandomMeme(audios: List<MemeAudioEntity>) {
        playSlapSfx()
        playbackJob?.cancel()
        if (audios.isEmpty()) return

        playbackJob = scope.launch {
            delay(115L) // Let the slap crack land cleanly before the meme voice kicks in
            val candidates = if (audios.size > 1 && lastPlayedAudioId != null) {
                audios.filter { it.id != lastPlayedAudioId }
            } else {
                audios
            }
            val chosen = candidates.random()
            lastPlayedAudioId = chosen.id
            startMemeClip(chosen)
        }
    }

    fun playSlapSfx() {
        if (slapLoaded && slapSoundId != 0) {
            val pitch = Random.nextFloat() * 0.14f + 0.93f // Slight pitch variation per slap
            soundPool.play(slapSoundId, 1.0f, 1.0f, 1, 0, pitch)
        }
    }

    fun previewAudio(audio: MemeAudioEntity) {
        playbackJob?.cancel()
        if (_playingClipId.value == audio.id) {
            stopMemePlayback()
            return
        }
        startMemeClip(audio)
    }

    fun stopMemePlayback() {
        playbackJob?.cancel()
        envelopeSyncJob?.cancel()
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                reset()
                release()
            }
        } catch (_: Exception) {
        }
        mediaPlayer = null
        _isTalking.value = false
        _talkingAmplitude.value = 0f
        _playingClipId.value = null
    }

    private fun startMemeClip(audio: MemeAudioEntity) {
        envelopeSyncJob?.cancel()
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                reset()
                release()
            }
        } catch (_: Exception) {
        }
        mediaPlayer = null

        val file = File(audio.filePath)
        if (!file.exists()) {
            _isTalking.value = false
            _talkingAmplitude.value = 0f
            _playingClipId.value = null
            return
        }

        val envelope = parseEnvelope(audio.envelopeCsv)
        val player = MediaPlayer()
        mediaPlayer = player

        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            player.setDataSource(file.absolutePath)
            player.setOnPreparedListener { mp ->
                _playingClipId.value = audio.id
                _isTalking.value = true
                mp.start()
                startEnvelopeSyncLoop(mp, envelope)
            }
            player.setOnCompletionListener {
                stopMemePlayback()
            }
            player.setOnErrorListener { _, _, _ ->
                stopMemePlayback()
                true
            }
            player.prepareAsync()
        } catch (_: Exception) {
            stopMemePlayback()
        }
    }

    private fun startEnvelopeSyncLoop(mp: MediaPlayer, envelope: FloatArray) {
        envelopeSyncJob?.cancel()
        envelopeSyncJob = scope.launch {
            var smoothed = 0f
            while (isActive) {
                val playing = try {
                    mp.isPlaying
                } catch (_: Exception) {
                    false
                }
                if (!playing) break

                val posMs = try {
                    mp.currentPosition
                } catch (_: Exception) {
                    0
                }

                val targetAmp = if (envelope.isNotEmpty()) {
                    val idx = (posMs / 30).coerceIn(0, envelope.lastIndex)
                    val nextIdx = (idx + 1).coerceAtMost(envelope.lastIndex)
                    val frac = ((posMs % 30) / 30f).coerceIn(0f, 1f)
                    envelope[idx] * (1f - frac) + envelope[nextIdx] * frac
                } else {
                    // Fallback syllable cadence if codec envelope wasn't available
                    val t = posMs / 1000.0
                    val wave = abs(sin(t * 14.5) * 0.65 + sin(t * 23.0) * 0.35).toFloat()
                    wave.coerceIn(0.15f, 1f)
                }

                smoothed = smoothed * 0.35f + targetAmp * 0.65f
                _talkingAmplitude.value = smoothed.coerceIn(0f, 1f)
                delay(20L)
            }
            _talkingAmplitude.value = 0f
            _isTalking.value = false
        }
    }

    private fun parseEnvelope(csv: String): FloatArray {
        if (csv.isBlank()) return FloatArray(0)
        val parts = csv.split(",")
        val result = FloatArray(parts.size)
        for (i in parts.indices) {
            val v = parts[i].toIntOrNull() ?: 0
            result[i] = (v / 100f).coerceIn(0f, 1f)
        }
        return result
    }

    fun release() {
        stopMemePlayback()
        try {
            soundPool.release()
        } catch (_: Exception) {
        }
    }
}
